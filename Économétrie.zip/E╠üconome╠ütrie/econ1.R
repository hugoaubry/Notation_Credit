##### IMPORT DES DONNEES #####

# Si besoin : install.packages("readxl")
library(readxl)
library(ordinal)

# Chemin vers le fichier Excel (adapte si nécessaire)
chemin <- "/Users/hugoaubry/Downloads/Économétrie/merged_all_sectors_with_rating_ord.xlsx"

# Import du fichier Excel
merged_all_sectors_with_rating_ord <- read_excel(chemin)

# Vérification rapide (optionnel)
# print(names(merged_all_sectors_with_rating_ord))
# str(merged_all_sectors_with_rating_ord)

# Mise en forme des variables
merged_all_sectors_with_rating_ord$rating_ord <- factor(
  merged_all_sectors_with_rating_ord$rating_ord,
  ordered = TRUE
)

merged_all_sectors_with_rating_ord$sector <- factor(
  merged_all_sectors_with_rating_ord$sector
)


##### MODELE 1 : base #####

model1_baseline <- clm(
  rating_ord ~ 
    factor_business_profile +
    factor_leverage_coverage +
    factor_financial_policy +
    delta_other_considerations_soft,
  data = merged_all_sectors_with_rating_ord,
  link = "logit"
)

summary(model1_baseline)


##### MODELE 3 : interaction secteur x leverage_coverage #####

model3_interaction <- clm(
  rating_ord ~ 
    factor_business_profile +
    factor_leverage_coverage * sector +   # interaction
    factor_financial_policy +
    delta_other_considerations_soft,
  data = merged_all_sectors_with_rating_ord,
  link = "logit"
)

summary(model3_interaction)